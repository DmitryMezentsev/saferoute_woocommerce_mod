=== SafeRoute WooCommerce ===
Contributors: Dmitry Mezentsev
Tags: saferoute, shipping, woocommerce, shop, доставка, агрегатор
Requires at least: 4.9
Tested up to: 4.9
Stable tag: 1.0.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Модуль для быстрой интеграции виджета SafeRoute в магазин на основе WooCommerce.
https://saferoute.ru/



== Installation ==
PDF с инструкциями по установке можно найти в архиве по ссылке:
https://github.com/DmitryMezentsev/saferoute_woocommerce_mod/raw/master/build/saferoute_woocommerce.zip



== Changelog ==

= 1.0.0 =
* Первая версия плагина



== Upgrade Notice ==

= 1.0.0 =
* Первая версия плагина