=== SafeRoute WooCommerce ===
Contributors: dmitrymezentsev
Tags: saferoute, shipping, woocommerce, shop, доставка, агрегатор
Requires at least: 4.9
Tested up to: 4.9
Requires PHP: 5.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Модуль для быстрой интеграции виджета SafeRoute в магазин на основе WooCommerce.
https://saferoute.ru/



== Installation ==
PDF с инструкциями по установке можно найти в архиве по ссылке:
https://github.com/DmitryMezentsev/saferoute_woocommerce_mod/raw/master/build/saferoute_woocommerce.zip



== Changelog ==

= 1.0.2 =
* Виртуальные и скачиваемые товары теперь не передаются в виджет.
* Исправлен баг, когда при оформлении заказа стоимость доставки не сохранялась.
= 1.0.1 =
* Увеличен timeout для запросов к серверу SafeRoute
= 1.0.0 =
* Первая версия плагина



== Upgrade Notice ==

= 1.0.2 =
* Виртуальные и скачиваемые товары теперь не передаются в виджет.
* Исправлен баг, когда при оформлении заказа стоимость доставки не сохранялась.
= 1.0.1 =
* Увеличен timeout для запросов к серверу SafeRoute
= 1.0.0 =
* Первая версия плагина