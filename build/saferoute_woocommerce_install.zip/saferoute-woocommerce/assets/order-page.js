/* global SafeRouteCartWidget */

(($) => {

})(jQuery || $);
