<div class="saferoute_widget_block">
    <h3><?php _e('Select Shipping Type', self::TEXT_DOMAIN); ?></h3>
    <div id="sr_widget"></div>
</div>
<div class="saferoute_delivery_info"></div>