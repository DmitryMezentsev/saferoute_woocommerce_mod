=== DDelivery WooCommerce ===
Contributors: Dmitry Mezentsev
Tags: ddelivery, shipping, woocommerce, shop, доставка, агрегатор, дделивери
Requires at least: 4.9
Tested up to: 4.9
Stable tag: 1.0.3
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Модуль для быстрой интеграции виджета DDelivery в магазин на основе WooCommerce.
https://ddelivery.ru/



== Installation ==
PDF с инструкциями по установке можно найти в архиве по ссылке:
https://github.com/DmitryMezentsev/ddelivery_woocommerce_mod/raw/master/build/ddelivery_woocommerce.zip



== Changelog ==

= 1.0.3 =
* Исправлена ошибка с выводом уведомлений в амдинке.
= 1.0.2 =
* Исправлена ошибка с неправильными путями к файлам плагина.
= 1.0.1 =
* Добавлен учет скидок по купонам. Размер скидки по купонам передается как общая скидка на весь заказ.



== Upgrade Notice ==

= 1.0.3 =
Исправлена ошибка с выводом уведомлений в амдинке.
= 1.0.2 =
Исправлена ошибка с неправильными путями к файлам плагина.
= 1.0.1 =
Добавлен учет скидок по купонам. Размер скидки по купонам передается как общая скидка на весь заказ.