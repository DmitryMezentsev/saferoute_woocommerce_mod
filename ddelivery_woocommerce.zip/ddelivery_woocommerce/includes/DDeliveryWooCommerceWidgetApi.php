<?php

require_once 'DDeliveryWooCommerceBase.php';

/**
 * Класс, добавляющий в движок API для взаимодействия с корзинным виджетом
 */
class DDeliveryWooCommerceWidgetApi extends DDeliveryWooCommerceBase
{
    public static function init()
    {

    }
}